# Third-party notices

This collection adapts three independent skills. It is not an official release of, or endorsed by, their authors. Keep the notices and accompanying license texts with redistributions.

| Bundled module | Upstream work and copyright | License |
|---|---|---|
| `modules/layout` | [UI UX Pro Max](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill), © 2024 Next Level Builder. Supplied Aside adaptation, search scripts, reference tables and dataset retained. The bundled entry uses portable paths and read-only search. | [MIT](licenses/layout-MIT.txt) |
| `modules/details` | [Make Interfaces Feel Better](https://github.com/jakubkrehel/make-interfaces-feel-better), © 2026 Jakub Krehel. Skill body and all five linked guides; host-specific discovery metadata omitted. | [MIT](licenses/details-MIT.txt) |
| `modules/accessibility` | [Web Quality Skills: Accessibility](https://github.com/addyosmani/web-quality-skills), © 2026 Addy Osmani. Skill body and both linked references. Optional install commands removed; links adapted. | [MIT](licenses/accessibility-MIT.txt) |

The layout catalog includes metadata derived from [Phosphor Icons core 2.1.1](https://github.com/phosphor-icons/core), © 2023 Phosphor Icons ([MIT](licenses/phosphor-MIT.txt)). Google Fonts names and license metadata are catalog records, not bundled fonts. No font files, icon artwork, third-party runtimes, or rights to linked external assets are supplied. See the source fields in the shipped catalog for individual records and license identifiers.

The new wrapper and routing text may be copied, adapted, and redistributed with this pack. See [the manifest](package-manifest.json) for revisions, source-file digests, and modifications. The prepared layout snapshot did not include a verified Git commit; its content hashes identify the exact input instead.
